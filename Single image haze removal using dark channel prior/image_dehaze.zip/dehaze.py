import cv2;
import math;
import numpy as np;

def DarkChannel(im,sz):
    b,g,r = cv2.split(im)
    # 先求出每个像素最暗的通道颜色
    dc = cv2.min(cv2.min(r,g),b);
    # 操作核为矩形核
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT,(sz,sz))
    # 腐蚀是计算一个窗内的最低值作为当前窗像素中心的值
    dark = cv2.erode(dc,kernel)
    return dark

def AtmLight(im,dark):
    [h,w] = im.shape[:2]
    print("[h,w]:", str([h,w]))
    imsz = h*w
    # numpx：表示要选择的其中暗通道最亮的numpx个像素（选择其中百分之0.1的像素）
    numpx = int(max(math.floor(imsz/1000),1))
    darkvec = dark.reshape(imsz);
    imvec = im.reshape(imsz,3);

    # 对数组中的元素进行从小到大排序,并返回相应序列元素的数组下标
    indices = darkvec.argsort();
    indices = indices[imsz-numpx::]
    print(indices)

    # 把暗通道最亮的像素值相加，然后取平均
    atmsum = np.zeros([1,3])
    for ind in range(1,numpx):
       atmsum = atmsum + imvec[indices[ind]]
    A = atmsum / numpx;

    return A

def TransmissionEstimate(im,A,sz):
    omega = 0.95;
    im3 = np.empty(im.shape,im.dtype);

    for ind in range(0,3):
        im3[:,:,ind] = im[:,:,ind]/A[0,ind]
    # 求两次min相当于再调用一次DarkChannel()函数
    transmission = 1 - omega*DarkChannel(im3,sz);
    return transmission

def Guidedfilter(im,p,r,eps):
    mean_I = cv2.boxFilter(im,cv2.CV_64F,(r,r));
    mean_p = cv2.boxFilter(p, cv2.CV_64F,(r,r));
    mean_Ip = cv2.boxFilter(im*p,cv2.CV_64F,(r,r));
    cov_Ip = mean_Ip - mean_I*mean_p;

    mean_II = cv2.boxFilter(im*im,cv2.CV_64F,(r,r));
    var_I   = mean_II - mean_I*mean_I;

    a = cov_Ip/(var_I + eps);
    b = mean_p - a*mean_I;

    mean_a = cv2.boxFilter(a,cv2.CV_64F,(r,r));
    mean_b = cv2.boxFilter(b,cv2.CV_64F,(r,r));

    q = mean_a*im + mean_b;
    return q;

def TransmissionRefine(im,et):
    gray = cv2.cvtColor(im,cv2.COLOR_BGR2GRAY);
    gray = np.float64(gray)/255;
    r = 60;
    eps = 0.0001;
    t = Guidedfilter(gray,et,r,eps);

    return t;

def Recover(im,t,A,tx = 0.1):
    res = np.empty(im.shape,im.dtype);
    t = cv2.max(t,tx);

    for ind in range(0,3):
        res[:,:,ind] = (im[:,:,ind]-A[0,ind])/t + A[0,ind]

    return res

if __name__ == '__main__':
    import sys
    try:
        fn = sys.argv[1]
    except:
        fn = './image/15.png'

    def nothing(*argv):
        pass

    src = cv2.imread(fn);
    # 转换为浮点数再计算
    I = src.astype('float64')/255;
    #cv2.imshow('I', src);

    # 求出暗通道
    dark = DarkChannel(I,15);
    #cv2.imshow("dark", dark);

    # 计算大气光强
    A = AtmLight(I,dark);

    # 估计$\widetilde{\mathbf{t}}$并将其作为约束，使用引导滤波细化
    te = TransmissionEstimate(I,A,15);
    t = TransmissionRefine(src,te);
    #cv2.imshow("t", t);

    # 恢复场景radiance
    J = Recover(I,t,A,0.1);
    cv2.imshow('J', J);

    cv2.waitKey();
    
