import cv2
import numpy as np
import closed_form_matting

image = cv2.imread('test_dezeming/source.png', cv2.IMREAD_COLOR) / 255.0
trimap = cv2.imread('test_dezeming/trimap.png', cv2.IMREAD_GRAYSCALE) / 255.0

alpha = closed_form_matting.closed_form_matting_with_trimap(image, trimap)

alpha = cv2.merge([alpha*255,alpha*255,alpha*255])
cv2.imwrite('test_dezeming/alpha.jpg', alpha)

