import json
import numpy as np

"""
************************************************
***************   加载内参参数   *****************
************************************************
"""
def load_para(para_path):
    #para = np.load(para_path, allow_pickle=True).item()
    f = open(para_path, 'r')
    content = f.read()
    para = json.loads(content)
    matrix = np.array(para["intrinsic"])
    dist = np.array(para["distortion"])
    return matrix, dist

intrinsic, distortion = load_para("camera_intr_opt.json")
print(intrinsic)
print(distortion)
"""
************************************************
***************   检测棋盘格角点   ***************
************************************************
"""
#棋盘格模板规格，即内角点个数
w = 7
h = 4
objp = np.zeros((w*h,3), np.float32)
objp[:,:2] = np.mgrid[0:w,0:h].T.reshape(-1,2)

imagename = 'D:/Dataset/Marker/photos/5.jpg'
import cv2
img = cv2.imread(imagename)
gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
# 找到棋盘图像(8位灰度或彩色图像)中的棋盘格角点
ret, corners = cv2.findChessboardCorners(gray, (w,h),None)
if ret == True:
    # 角点精确检测
    # 输入图像 角点初始坐标 搜索窗口为2*winsize+1 死区 求角点的迭代终止条件
    # 设定阈值
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001)
    # 就把它优化到亚像素级
    corners2 = cv2.cornerSubPix(gray,corners,(11,11),(-1,-1),criteria)
    # 将角点在图像上显示
    img1 = img.copy()
    cv2.drawChessboardCorners(img1, (w,h), corners, ret)
    cv2.imwrite('1_corners_1.jpg', img1)
    # 计算旋转和平移矩阵
    retval, rvecs, tvecs, inliers = cv2.solvePnPRansac(objp, corners2, intrinsic, distortion)

# 重投影检测
# 坐标轴绘制：
def draw(img, corners, imgpts):
    corner = tuple(corners[0].ravel())
    print(tuple(imgpts[0].ravel()))
    img = cv2.line(img, tuple(map(int, corner)), tuple(map(int, imgpts[0].ravel())), (255,0,0), 15)
    img = cv2.line(img, tuple(map(int, corner)), tuple(map(int, imgpts[1].ravel())), (0,255,0), 15)
    img = cv2.line(img, tuple(map(int, corner)), tuple(map(int, imgpts[2].ravel())), (0,0,255), 15)
    return img

if ret == True:
    # 投影坐标轴
    axis = np.float32([[3, 0, 0], [0, 3, 0], [0, 0, -3]]).reshape(-1, 3)
    imgpts, jac = cv2.projectPoints(axis, rvecs, tvecs, intrinsic, distortion)
    img2 = draw(img, corners, imgpts)
    cv2.imwrite('1_corners_2.jpg', img)

"""
************************************************
***************   投影一个立方体   ***************
************************************************
"""

def drawBox(img, corners, imgpts):
    imgpts = np.int32(imgpts).reshape(-1,2)
    # draw ground floor in green
    img = cv2.drawContours(img, [imgpts[:4]],-1,(0,255,0),-3)
    # draw pillars in blue color
    for i,j in zip(range(4),range(4,8)):
        img = cv2.line(img, tuple(imgpts[i]), tuple(imgpts[j]),(255),3)
    # draw top layer in red color
    img = cv2.drawContours(img, [imgpts[4:]],-1,(0,0,255),3)
    return img

if ret == True:
    # 投影坐标轴
    axis = np.float32([[0, 0, 0], [0, 3, 0], [3, 3, 0], [3, 0, 0],
                       [0, 0, -3], [0, 3, -3], [3, 3, -3], [3, 0, -3]])
    imgpts, jac = cv2.projectPoints(axis, rvecs, tvecs, intrinsic, distortion)
    img3 = drawBox(img, corners, imgpts)
    cv2.imwrite('1_corners_3.jpg', img)





