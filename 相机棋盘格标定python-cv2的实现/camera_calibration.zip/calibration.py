import cv2
import numpy as np
# glob用于获得文件夹下全部图像文件
import glob

"""
************************************************
**************   marker的提取   *****************
************************************************
"""

# 设定阈值
criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001)
#棋盘格模板规格，即内角点个数
w = 7
h = 4

# 首先设置一个世界坐标，为了方便起见，我们直接设板子左上角的点就在世界坐标原点，然后第一排的第二个点在世界坐标[1. 0. 0.]位置：
# 世界坐标系中的棋盘格点,即[0. 0. 0.], [1. 0. 0.], [2. 0. 0.],....,[5. 3. 0.]
# 在标定时，都会默认这种世界坐标形式，并且认为物体没有动，动的只是相机（后面计算得到的每幅图[i]的rvecs[i]和tvecs[i]都是独立的）。
objp = np.zeros((w*h,3), np.float32)
objp[:,:2] = np.mgrid[0:w,0:h].T.reshape(-1,2)
# 储存棋盘格角点的世界坐标和图像坐标对
objpoints = [] # 在世界坐标系中的三维点
imgpoints = [] # 在图像平面的二维点

# 获取图像序列
images = glob.glob('D:/Dataset/Marker/photos/*.jpg')
# 依次处理每个图像
count = 0
for fname in images:
    count = count + 1
    img = cv2.imread(fname)
    gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    # 找到棋盘图像(8位灰度或彩色图像)中的棋盘格角点
    ret, corners = cv2.findChessboardCorners(gray, (w,h),None)
    # 如果找到足够点对，将其存储起来
    if ret == True:
        # 角点精确检测
        # 输入图像 角点初始坐标 搜索窗口为2*winsize+1 死区 求角点的迭代终止条件
        cv2.cornerSubPix(gray,corners,(11,11),(-1,-1),criteria)
        objpoints.append(objp)
        imgpoints.append(corners)
        # 将角点在图像上显示
        cv2.drawChessboardCorners(img, (w,h), corners, ret)
        # cv2.imshow('findCorners',img)
        cv2.waitKey(1000)
    # cv2.imwrite('D:/Dataset/Marker/output/' + str(count) + '.jpg', img)
cv2.destroyAllWindows()

"""
************************************************
**************   相机标定   *****************
************************************************
"""
# 标定结果 相机的内参数矩阵 畸变系数 旋转矩阵 平移向量
ret, mtx, dist, rvecs, tvecs = cv2.calibrateCamera(objpoints, imgpoints, gray.shape[::-1], None, None)
print (("ret:"),ret)
# 内参矩阵
print (("mtx:\n"),mtx)
# dist:畸变系数(k_1,k_2,p_1,p_2,k_3)
print (("dist:\n"),dist)
# rvecs:旋转向量(外参)；tvecs:平移向量(外参)
print (("rvecs:\n"),rvecs)
print (("tvecs:\n"),tvecs)


# 去畸变：
# 假设我们的图像没有太大畸变，就不需要先恢复到未畸变的图像再处理
"""
# 我们已经得到了相机内参和畸变系数，
# 在将图像去畸变之前，还可以使用cv.getOptimalNewCameraMatrix()优化内参和畸变系数，
# 通过设定自由比例因子alpha。
# 当alpha设为0时，将会返回一个剪裁过的将去畸变后不想要的像素去掉的内参和畸变系数；
# 当alpha设为1时，会返回一个包含额外黑色像素点的内参和畸变系数，并返回一个ROI用于将其剪裁掉
img2 = cv2.imread('D:/Dataset/Marker/photos/1.jpg')
h,w = img2.shape[:2]
newcameramtx, roi=cv2.getOptimalNewCameraMatrix(mtx,dist,(w,h),0,(w,h))
dst = cv2.undistort(img2, mtx, dist, None, newcameramtx)

# 根据前面ROI区域裁剪图片
x,y,w,h = roi
dst = dst[y:y+h, x:x+w]
cv2.imwrite('calibresult.jpg',dst)
"""

total_error = 0
for i in range(len(objpoints)):
    imgpoints2, _ = cv2.projectPoints(objpoints[i], rvecs[i], tvecs[i], mtx, dist)
    error = cv2.norm(imgpoints[i],imgpoints2, cv2.NORM_L2)/len(imgpoints2)
    total_error += error
print(("total error: "), total_error/len(objpoints))

# 重投影：用第一张图做测试，将三维空间中位于objpoints[0]的那些点（第一张图像上的角点的实际空间位置）变换到图像上
# 注意这里需要假设标定板在世界空间是固定不变的，而位置变的只是相机（旋转和平移 rvecs[0], tvecs[0]）
img = cv2.imread(images[0])
imgpoints2, _ = cv2.projectPoints(objpoints[0], rvecs[0], tvecs[0], mtx, dist)
for i in range(len(imgpoints2)):
    cv2.circle(img, (int(imgpoints2[i][0][0]), int(imgpoints2[i][0][1])), 10, (0, 0, 255), -1)
cv2.imwrite('reprojection.jpg',img)


"""
************************************************
***************   保存内参参数   *****************
************************************************
"""
import json
def save_para(filename, matrix, dist):
    camera_para_dict = {"intrinsic": matrix, "distortion": dist}
    temp = json.dumps(camera_para_dict)
    file = open(filename, 'w')
    file.write(temp)
    file.close()

# 保存参数
save_para("camera_intr_opt.json",mtx.tolist(),dist.tolist())
print(mtx)
print(dist)














