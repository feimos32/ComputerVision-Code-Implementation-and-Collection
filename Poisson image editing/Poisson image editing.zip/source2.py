"""
Dezeming Family
"""

from scipy.sparse.linalg import spsolve
from scipy.sparse import linalg as linalg
from scipy import sparse
import cv2
import numpy as np

# 要求src、dst和mask必须尺寸一样大
# 传入必须都是单通道
# type 0表示使用源图梯度 1表示源图梯度和目的图梯度取平均 2表示取源图或目的图的最大梯度
def poisson_cloning(src, dst, mask, type):
    # 计算源图像和背景图像的梯度，这里用Laplacian作为梯度
    src_t= src.astype(np.float32)
    dst_t = dst.astype(np.float32)
    delta_src = cv2.Laplacian(src.astype(np.float32), cv2.CV_32FC1, 1)
    delta_dst = cv2.Laplacian(dst.astype(np.float32), cv2.CV_32FC1, 1)
    delta_dst = delta_dst * 0.2
    #print(src)
    #print(delta_src)
    #print(delta_dst)
    # 梯度等于目标图像g的梯度
    delta = delta_src
    # 梯度平均，用源图的梯度的百分之50加上目的图的梯度的百分之50作为目的梯度
    if (1 == type):
        delta = 0.5 * delta_src + 0.5 * delta_dst
    # 混合最大梯度
    if (2 == type):
        h, w = delta_src.shape
        for i in range(1, h - 1):
            for j in range(1, w - 1):
                """
                # 测试：梯度等于目标图像g的梯度
                vp_t = float(src[i - 1, j]) - float(src[i, j])
                vp_b = float(src[i + 1, j]) - float(src[i, j])
                vp_l = float(src[i, j - 1]) - float(src[i, j])
                vp_r = float(src[i, j + 1]) - float(src[i, j])
                """
                # 第i行第j列
                if (abs(src_t[i-1,j]-src_t[i,j]) > abs(dst_t[i-1,j]-dst_t[i,j])):
                    vp_t = src_t[i-1,j]-src_t[i,j]
                else:
                    vp_t = dst_t[i-1,j]-dst_t[i,j]
                if (abs(src_t[i+1,j]-src_t[i,j]) > abs(dst_t[i+1,j]-dst_t[i,j])):
                    vp_b = src_t[i+1,j]-src_t[i,j]
                else:
                    vp_b = dst_t[i+1,j]-dst_t[i,j]
                if (abs(src_t[i,j-1]-src_t[i,j]) > abs(dst_t[i,j-1]-dst_t[i,j])):
                    vp_l = src_t[i,j-1]-src_t[i,j]
                else:
                    vp_l = dst_t[i,j-1]-dst_t[i,j]
                if (abs(src_t[i,j+1]-src_t[i,j]) > abs(dst_t[i,j+1]-dst_t[i,j])):
                    vp_r = src_t[i,j+1]-src_t[i,j]
                else:
                    vp_r = dst_t[i,j+1]-dst_t[i,j]

                delta[i, j] = vp_t + vp_b + vp_l + vp_r
    # print(delta)
    h, w = mask.shape
    num_pxls = h * w
    # sparse.eye返回的内容是一个coo_matrix，全名为：A sparse matrix in COOrdinate format，
    # 是一种基于坐标格式的稀疏矩阵，每一个矩阵项是一个三元组（行,列,值)。
    # format="dok"，表示创建一种类似于coo_matrix但又基于字典的稀疏矩阵存储方式, key由非零元素的的坐标值tuple(row, column)组成
    # 本代码调用以后得到 (0,0) 1.0   (1,1) 1.0   (2,2) 1.0 ······
    laplacian = sparse.eye(num_pxls, dtype='float64', format="dok")
    for i in range(1, h-1):
        for j in range(1, w-1):
            # 第i行第j列
            if mask[i, j]:
                if mask[i,j-1]:
                    laplacian[i*w+j, i*w+(j-1)] = 1
                else:
                    delta[i,j] = delta[i,j] - dst[i, j - 1]
                if mask[i-1, j]:
                    laplacian[i*w+j, (i-1)*w+j] = 1
                else:
                    delta[i,j] = delta[i,j] - dst[i-1, j]
                if mask[i, j+1]:
                    laplacian[i*w+j, i*w+(j+1)] = 1
                else:
                    delta[i,j] = delta[i,j] - dst[i, j+1]
                if mask[i+1, j]:
                    laplacian[i*w+j, (i+1)*w+j] = 1
                else:
                    delta[i,j] = delta[i,j] - dst[i+1, j]
                laplacian[i * w + j, i * w + j] = -4
    # 如果没有mask，就相当于一个（w * h, w * h）的单位矩阵L乘以x得到背景(w*h, 1)
    # 则求解得到的x就是背景值(w * h, 1)
    delta[np.where(mask == 0)] = dst[np.where(mask == 0)]
    # 转为csr格式(Compressed Sparse Row)便于操作

    # 方式1：使用spsolve求解器
    # x = spsolve(laplacian.tocsr(), delta.flatten())
    # x = np.clip(x, 0, 255)
    # 方式2：使用linalg.cg求解器
    x = linalg.cg(laplacian.tocsr(), delta.flatten())
    x = np.clip(x[0], 0, 255)
    return x.reshape(dst.shape).astype(np.uint8)

folder = "images2/"

# 获取图像mask
im_mask=cv2.imread(folder + "mask_2.png")
mask = cv2.cvtColor(im_mask,cv2.COLOR_RGB2GRAY)
mask[np.where(mask > 0)] = 255.0

# 前景图g
im_aim=cv2.imread(folder + "aim.png")
b_aim,g_aim,r_aim=cv2.split(im_aim)

# 背景图$f^{*}$
im_back=cv2.imread(folder + "back.png")
b_back,g_back,r_back=cv2.split(im_back)

# 三通道分别克隆
b_out = poisson_cloning(b_aim, b_back, mask)
g_out = poisson_cloning(g_aim, g_back, mask)
r_out = poisson_cloning(r_aim, r_back, mask)

# 合并结果并输出
img=cv2.merge((b_out,g_out,r_out))
cv2.imwrite(folder + "img.png",img)





